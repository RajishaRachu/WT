<?php

include_once("control/Controller.php");
$controller = new Controller();
$controller->invoke();

?>